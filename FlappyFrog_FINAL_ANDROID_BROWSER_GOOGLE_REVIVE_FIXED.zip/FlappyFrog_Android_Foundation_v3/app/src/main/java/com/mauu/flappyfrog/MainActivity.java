package com.mauu.flappyfrog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.FullScreenContentCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean webViewReady;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;
    private static final String NATIVE_AUTH_URL = "https://jeetrajpopat36.github.io/flappy--frog/?flappyNativeAuth=1";
    private String pendingGoogleToken;

    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUi();
        MobileAds.initialize(this, status -> loadRewardedAd());
        loadInterstitialAd();
        setupWebView();
        handleAuthIntent(getIntent());
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF08130B);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                webViewReady = true;
                deliverPendingGoogleToken();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new NativeAdsBridge(), "FlappyFrogNativeAds");
        // Keep the old alias harmlessly available for backward compatibility.
        webView.addJavascriptInterface(new NativeAdsBridge(), "AndroidAds");
        webView.addJavascriptInterface(new NativeGoogleBridge(), "AndroidGoogle");
        setContentView(webView);
        webView.loadUrl("https://jeetrajpopat36.github.io/flappy--frog/");
    }

    private void handleAuthIntent(Intent intent) {
        if (intent == null) return;
        Uri data = intent.getData();
        if (data == null || !"flappyfrog".equalsIgnoreCase(data.getScheme()) ||
                !"google-auth".equalsIgnoreCase(data.getHost())) return;
        String token = data.getQueryParameter("token");
        if (token == null || token.trim().isEmpty()) return;
        pendingGoogleToken = token;
        deliverPendingGoogleToken();
    }

    private String jsQuote(String value) {
        return JSONObject.quote(value == null ? "" : value);
    }

    private void deliverPendingGoogleToken() {
        if (pendingGoogleToken == null || webView == null || !webViewReady) return;
        final String token = pendingGoogleToken;
        pendingGoogleToken = null;
        callJs("window.FlappyFrogNativeGoogleResult&&window.FlappyFrogNativeGoogleResult(" + jsQuote(token) + ");");
    }

    private class NativeGoogleBridge {
        @JavascriptInterface public boolean isConfigured() { return true; }
        @JavascriptInterface public void startGoogleSignIn() {
            runOnUiThread(() -> {
                try {
                    Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(NATIVE_AUTH_URL));
                    browser.addCategory(Intent.CATEGORY_BROWSABLE);
                    startActivity(browser);
                } catch (Exception e) {
                    callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError(" +
                            jsQuote("Could not open the browser for Google Sign-In. Please try again.") + ");");
                }
            });
        }
    }

    private class NativeAdsBridge {
        @JavascriptInterface public boolean isRewardedAvailable() { return rewardedAd != null; }
        @JavascriptInterface public boolean showRewardedAd() {
            if (rewardedAd == null) {
                runOnUiThread(() -> loadRewardedAd());
                return false;
            }
            runOnUiThread(() -> {
                if (rewardedAd == null) return;
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        loadRewardedAd();
                        callJs("window.__flappyRewardUnavailable&&window.__flappyRewardUnavailable();");
                    }
                    @Override public void onAdFailedToShowFullScreenContent(
                            com.google.android.gms.ads.AdError adError) {
                        loadRewardedAd();
                        callJs("window.__flappyRewardUnavailable&&window.__flappyRewardUnavailable();");
                    }
                });
                ad.show(MainActivity.this, rewardItem ->
                        callJs("window.__flappyRewardEarned&&window.__flappyRewardEarned();"));
            });
            return true;
        }
        @JavascriptInterface public boolean isInterstitialAvailable() { return interstitialAd != null; }
        @JavascriptInterface public boolean showInterstitial() {
            if (interstitialAd == null) { loadInterstitialAd(); return false; }
            runOnUiThread(() -> {
                if (interstitialAd == null) return;
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.show(MainActivity.this);
                loadInterstitialAd();
            });
            return true;
        }
    }

    private void loadRewardedAd(){
        if (rewardedAd != null) return;
        RewardedAd.load(this,TEST_REWARDED_ID,new AdRequest.Builder().build(),new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(RewardedAd ad){
                rewardedAd=ad;
                callJs("window.FlappyFrogRewardedAdReady&&window.FlappyFrogRewardedAdReady();");
            }
            @Override public void onAdFailedToLoad(LoadAdError error){rewardedAd=null;}
        });
    }
    private void loadInterstitialAd(){
        InterstitialAd.load(this,TEST_INTERSTITIAL_ID,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){
            @Override public void onAdLoaded(InterstitialAd ad){interstitialAd=ad;}
            @Override public void onAdFailedToLoad(LoadAdError error){interstitialAd=null;}
        });
    }

    private boolean keyboardVisible(){
        Rect r=new Rect();
        View root=getWindow().getDecorView();
        root.getWindowVisibleDisplayFrame(r);
        int h=root.getRootView().getHeight();
        return h-r.bottom > h*0.18f;
    }

    @Override public void onBackPressed(){
        if(keyboardVisible()){
            InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if(webView!=null)imm.hideSoftInputFromWindow(webView.getWindowToken(),0);
            if(webView!=null)webView.clearFocus();
            return;
        }
        if(webView!=null){
            webView.evaluateJavascript("window.FlappyFrogHandleAndroidBack?window.FlappyFrogHandleAndroidBack():false;", value->{
                if("false".equals(value)||"null".equals(value))finish();
            });
        }else super.onBackPressed();
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        handleAuthIntent(intent);
    }
    @Override protected void onResume(){super.onResume();hideSystemUi();deliverPendingGoogleToken();}
}
