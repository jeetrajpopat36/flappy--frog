# Flappy Frog Android Foundation V3

Package: `com.mauu.flappyfrog`

This version keeps the V35 game on HTTPS GitHub Pages and adds native Android Google sign-in via Credential Manager. Google sign-in requires the real Firebase Android `google-services.json` for package `com.mauu.flappyfrog`, including the OAuth client configuration.

Before building the final V3 APK, place the real `google-services.json` at the repository root. The GitHub Actions workflow copies it into `app/src/main/assets/` at build time. Do not commit service-account/private credentials.

The web Firebase config remains public by design; protect data with Firebase Auth, Firestore Rules, App Check, and server-side validation for competition.
