# Flappy Frog release rules. The initial build intentionally keeps shrinking disabled.
