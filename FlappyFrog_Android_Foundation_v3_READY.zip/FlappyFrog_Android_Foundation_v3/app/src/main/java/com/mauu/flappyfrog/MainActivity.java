package com.mauu.flappyfrog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;
    private CredentialManager credentialManager;
    private final Executor credentialExecutor = Executors.newSingleThreadExecutor();

    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUi();
        credentialManager = CredentialManager.create(this);
        MobileAds.initialize(this, status -> loadRewardedAd());
        loadInterstitialAd();
        setupWebView();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF08130B);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new NativeAdsBridge(), "FlappyFrogNativeAds");
        // Keep the old alias harmlessly available for backward compatibility.
        webView.addJavascriptInterface(new NativeAdsBridge(), "AndroidAds");
        webView.addJavascriptInterface(new NativeGoogleBridge(), "AndroidGoogle");
        setContentView(webView);
        webView.loadUrl("https://jeetrajpopat36.github.io/flappy--frog/");
    }

    private boolean hasGoogleConfig() {
        try {
            InputStream in = getAssets().open("google-services.json");
            StringBuilder b = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String line; while ((line = r.readLine()) != null) b.append(line);
            in.close();
            JSONObject root = new JSONObject(b.toString());
            JSONArray clients = root.optJSONArray("client");
            if (clients == null) return false;
            for (int i=0;i<clients.length();i++) {
                JSONObject c = clients.optJSONObject(i);
                JSONObject info = c == null ? null : c.optJSONObject("client_info");
                JSONObject androidInfo = info == null ? null : info.optJSONObject("android_client_info");
                if (androidInfo != null && getPackageName().equals(androidInfo.optString("package_name"))) {
                    JSONArray oauth = c.optJSONArray("oauth_client");
                    if (oauth != null) for (int j=0;j<oauth.length();j++) {
                        JSONObject o=oauth.optJSONObject(j);
                        if (o != null && o.optInt("client_type",0)==3 && o.optString("client_id","").length()>0) return true;
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private String readWebClientId() {
        try {
            InputStream in = getAssets().open("google-services.json");
            StringBuilder b = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            String line; while ((line = r.readLine()) != null) b.append(line);
            in.close();
            JSONObject root = new JSONObject(b.toString());
            JSONArray clients = root.optJSONArray("client");
            if (clients == null) return "";
            for (int i=0;i<clients.length();i++) {
                JSONObject c=clients.optJSONObject(i);
                JSONObject info=c==null?null:c.optJSONObject("client_info");
                JSONObject ai=info==null?null:info.optJSONObject("android_client_info");
                if(ai==null || !getPackageName().equals(ai.optString("package_name"))) continue;
                JSONArray oauth=c.optJSONArray("oauth_client");
                if(oauth!=null) for(int j=0;j<oauth.length();j++){
                    JSONObject o=oauth.optJSONObject(j);
                    if(o!=null && o.optInt("client_type",0)==3)return o.optString("client_id","");
                }
            }
        } catch(Exception ignored) {}
        return "";
    }

    private void callJs(String script) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private String jsQuote(String s) { return JSONObject.quote(s == null ? "" : s); }

    private class NativeGoogleBridge {
        @JavascriptInterface public boolean isConfigured() { return hasGoogleConfig(); }
        @JavascriptInterface public void startGoogleSignIn() {
            runOnUiThread(() -> {
                final String webClientId=readWebClientId();
                if(webClientId.isEmpty()) { callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError('Android Google sign-in is not configured yet.');"); return; }
                try {
                    // Use the interactive GetGoogleIdOption flow recommended for a user-initiated
                    // Sign in with Google button. Showing all accounts avoids the re-authentication
                    // dead-end seen with the previous button-flow option on this device.
                    GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                            .setServerClientId(webClientId)
                            .setFilterByAuthorizedAccounts(false)
                            .setAutoSelectEnabled(false)
                            .build();
                    GetCredentialRequest request = new GetCredentialRequest.Builder()
                            .addCredentialOption(option)
                            .build();
                    credentialManager.getCredentialAsync(MainActivity.this, request, new CancellationSignal(), credentialExecutor,
                        new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                            @Override public void onResult(GetCredentialResponse response) {
                                Credential credential=response.getCredential();
                                if(credential instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                                    try {
                                        GoogleIdTokenCredential google=GoogleIdTokenCredential.createFrom(((CustomCredential)credential).getData());
                                        callJs("window.FlappyFrogNativeGoogleResult&&window.FlappyFrogNativeGoogleResult("+jsQuote(google.getIdToken())+");");
                                    } catch(Exception e) {
                                        callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError('Google returned an invalid sign-in credential.');");
                                    }
                                } else {
                                    callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError('No Google sign-in credential was returned.');");
                                }
                            }
                            @Override public void onError(GetCredentialException e) {
                                String msg = e == null ? "Google sign-in failed." : String.valueOf(e.getMessage());
                                callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError("+jsQuote(msg)+");");
                            }
                        });
                } catch(Exception e) { callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError("+jsQuote(e.getMessage())+");"); }
            });
        }
    }

    private class NativeAdsBridge {
        @JavascriptInterface public boolean isRewardedAvailable() { return rewardedAd != null; }
        @JavascriptInterface public boolean showRewardedAd() {
            if (rewardedAd == null) {
                runOnUiThread(() -> loadRewardedAd());
                return false;
            }
            runOnUiThread(() -> {
                if (rewardedAd == null) return;
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        loadRewardedAd();
                        callJs("window.__flappyRewardUnavailable&&window.__flappyRewardUnavailable();");
                    }
                    @Override public void onAdFailedToShowFullScreenContent(
                            com.google.android.gms.ads.AdError adError) {
                        loadRewardedAd();
                        callJs("window.__flappyRewardUnavailable&&window.__flappyRewardUnavailable();");
                    }
                });
                ad.show(MainActivity.this, rewardItem ->
                        callJs("window.__flappyRewardEarned&&window.__flappyRewardEarned();"));
            });
            return true;
        }
        @JavascriptInterface public boolean isInterstitialAvailable() { return interstitialAd != null; }
        @JavascriptInterface public boolean showInterstitial() {
            if (interstitialAd == null) { loadInterstitialAd(); return false; }
            runOnUiThread(() -> {
                if (interstitialAd == null) return;
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.show(MainActivity.this);
                loadInterstitialAd();
            });
            return true;
        }
    }

    private void loadRewardedAd(){
        if (rewardedAd != null) return;
        RewardedAd.load(this,TEST_REWARDED_ID,new AdRequest.Builder().build(),new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(RewardedAd ad){
                rewardedAd=ad;
                callJs("window.FlappyFrogRewardedAdReady&&window.FlappyFrogRewardedAdReady();");
            }
            @Override public void onAdFailedToLoad(LoadAdError error){rewardedAd=null;}
        });
    }
    private void loadInterstitialAd(){
        InterstitialAd.load(this,TEST_INTERSTITIAL_ID,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){
            @Override public void onAdLoaded(InterstitialAd ad){interstitialAd=ad;}
            @Override public void onAdFailedToLoad(LoadAdError error){interstitialAd=null;}
        });
    }

    private boolean keyboardVisible(){
        Rect r=new Rect();
        View root=getWindow().getDecorView();
        root.getWindowVisibleDisplayFrame(r);
        int h=root.getRootView().getHeight();
        return h-r.bottom > h*0.18f;
    }

    @Override public void onBackPressed(){
        if(keyboardVisible()){
            InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            if(webView!=null)imm.hideSoftInputFromWindow(webView.getWindowToken(),0);
            if(webView!=null)webView.clearFocus();
            return;
        }
        if(webView!=null){
            webView.evaluateJavascript("window.FlappyFrogHandleAndroidBack?window.FlappyFrogHandleAndroidBack():false;", value->{
                if("false".equals(value)||"null".equals(value))finish();
            });
        }else super.onBackPressed();
    }
    @Override protected void onResume(){super.onResume();hideSystemUi();}
}
