plugins { id("com.android.application") }

android {
    namespace = "com.mauu.flappyfrog"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mauu.flappyfrog"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    // Flappy Frog uses one fixed signing certificate for all controlled builds.
    // The keystore and passwords are supplied only by GitHub Actions secrets.
    signingConfigs {
        create("flappyFrog") {
            val keystorePath = System.getenv("FLAPPY_KEYSTORE_PATH")
                ?: error("FLAPPY_KEYSTORE_PATH is not set")
            val keystorePassword = System.getenv("FLAPPY_KEYSTORE_PASSWORD")
                ?: error("FLAPPY_KEYSTORE_PASSWORD is not set")
            val keyAliasValue = System.getenv("FLAPPY_KEY_ALIAS")
                ?: error("FLAPPY_KEY_ALIAS is not set")
            val keyPasswordValue = System.getenv("FLAPPY_KEY_PASSWORD")
                ?: error("FLAPPY_KEY_PASSWORD is not set")

            storeFile = file(keystorePath)
            storePassword = keystorePassword
            keyAlias = keyAliasValue
            keyPassword = keyPasswordValue
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("flappyFrog")
        }

        release {
            signingConfig = signingConfigs.getByName("flappyFrog")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.gms:play-services-auth:21.6.0")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}
