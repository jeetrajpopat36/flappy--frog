plugins { id("com.android.application") }

android {
    namespace = "com.mauu.flappyfrog"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mauu.flappyfrog"
        minSdk = 24
        targetSdk = 36
        versionCode = 2
        versionName = "1.0.1"
    }

    // Flappy Frog uses one fixed signing certificate for all controlled builds.
    // The keystore and passwords are supplied only by GitHub Actions secrets.
    signingConfigs {
        create("flappyFrog") {
            val keystorePath = System.getenv("FLAPPY_KEYSTORE_PATH")
                ?: error("FLAPPY_KEYSTORE_PATH is not set")
            val keystorePassword = System.getenv("FLAPPY_KEYSTORE_PASSWORD")
                ?: error("FLAPPY_KEYSTORE_PASSWORD is not set")
            val keyAliasValue = System.getenv("FLAPPY_KEY_ALIAS")
                ?: error("FLAPPY_KEY_ALIAS is not set")
            val keyPasswordValue = System.getenv("FLAPPY_KEY_PASSWORD")
                ?: error("FLAPPY_KEY_PASSWORD is not set")

            storeFile = file(keystorePath)
            storePassword = keystorePassword
            keyAlias = keyAliasValue
            keyPassword = keyPasswordValue
        }
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        debug {
            // Google demo ad units are used for debug builds so test taps never touch live ads.
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/5224354917\"")
            buildConfigField("String", "INTERSTITIAL_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/1033173712\"")
            signingConfig = signingConfigs.getByName("flappyFrog")
        }

        release {
            // Preserve the existing Flappy Frog production ad unit IDs in release builds.
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"ca-app-pub-2102873718403178/7728123767\"")
            buildConfigField("String", "INTERSTITIAL_AD_UNIT_ID", "\"ca-app-pub-2102873718403178/4848563575\"")
            signingConfig = signingConfigs.getByName("flappyFrog")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.15.0")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.gms:play-services-auth:21.6.0")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}
