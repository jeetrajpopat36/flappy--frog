package com.mauu.flappyfrog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.Toast;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final String TAG = "FlappyFrog";
    private static final String TRUSTED_HOST = "jeetrajpopat36.github.io";
    private static final String TRUSTED_ORIGIN = "https://jeetrajpopat36.github.io";
    private static final String TRUSTED_PATH = "/flappy--frog";
    private static final String HOST_BRIDGE_NAME = "FlappyFrogHost";
    private static final int RC_GOOGLE_SIGN_IN = 9001;

    private final Object adLock = new Object();
    private WebView webView;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;
    private boolean rewardedAdLoading;
    private boolean interstitialAdLoading;
    private boolean mobileAdsReady;
    private volatile JavaScriptReplyProxy pageReplyProxy;
    private GoogleSignInClient googleSignInClient;
    private String cachedWebClientId;

    /*
     * The injected bridge is origin-restricted by AndroidX WebKit and accepts
     * commands only from the main Flappy Frog document. This document-start
     * shim preserves the JavaScript API already used by the game HTML.
     */
    private static final String BRIDGE_BOOTSTRAP =
            "(function(){'use strict';" +
            "if(window.top!==window||window.__flappyNativeShimInstalled)return;" +
            "var host=window.FlappyFrogHost;if(!host||typeof host.postMessage!=='function')return;" +
            "window.__flappyNativeShimInstalled=true;" +
            "var s={rewarded:false,interstitial:false,googleConfigured:false};" +
            "function send(type){try{host.postMessage(JSON.stringify({type:type}));return true;}catch(e){return false;}}" +
            "host.onmessage=function(ev){var m;try{m=JSON.parse(ev.data||'{}');}catch(e){return;}" +
            "if(m.type==='state'){var wasRewarded=s.rewarded;s.rewarded=!!m.rewarded;s.interstitial=!!m.interstitial;s.googleConfigured=!!m.googleConfigured;" +
            "if(s.rewarded&&!wasRewarded&&typeof window.FlappyFrogRewardedAdReady==='function'){try{window.FlappyFrogRewardedAdReady();}catch(e){}}}" +
            "else if(m.type==='rewardEarned'){if(typeof window.__flappyRewardEarned==='function')window.__flappyRewardEarned();}" +
            "else if(m.type==='rewardUnavailable'){if(typeof window.__flappyRewardUnavailable==='function')window.__flappyRewardUnavailable();}" +
            "};" +
            "var ads={isRewardedAvailable:function(){return s.rewarded;}," +
            "showRewardedAd:function(){if(!s.rewarded){send('loadRewarded');return false;}s.rewarded=false;send('showRewarded');return true;}," +
            "isInterstitialAvailable:function(){return s.interstitial;}," +
            "showInterstitial:function(){if(!s.interstitial){send('loadInterstitial');return false;}s.interstitial=false;send('showInterstitial');return true;}};" +
            "window.FlappyFrogNativeAds=ads;window.AndroidAds=ads;" +
            "window.AndroidGoogle={isConfigured:function(){return s.googleConfigured;}," +
            "startGoogleSignIn:function(){if(!s.googleConfigured)return false;send('startGoogleSignIn');return true;}," +
            "clearGoogleSession:function(){send('clearGoogleSession');return true;}};" +
            "send('ready');})();";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUi();
        setupWebView();
        MobileAds.initialize(this, status -> runOnUiThread(() -> {
            mobileAdsReady = true;
            loadRewardedAd();
            loadInterstitialAd();
        }));
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private boolean isTrustedUrl(String value) {
        if (value == null || value.isEmpty()) return false;
        try {
            Uri uri = Uri.parse(value);
            String path = uri.getPath() == null ? "/" : uri.getPath();
            boolean validPath = path.equals(TRUSTED_PATH) || path.equals(TRUSTED_PATH + "/")
                    || path.startsWith(TRUSTED_PATH + "/");
            return "https".equalsIgnoreCase(uri.getScheme())
                    && TRUSTED_HOST.equalsIgnoreCase(uri.getHost())
                    && (uri.getPort() == -1 || uri.getPort() == 443)
                    && uri.getUserInfo() == null && validPath;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isTrustedOrigin(Uri origin) {
        return origin != null && "https".equalsIgnoreCase(origin.getScheme())
                && TRUSTED_HOST.equalsIgnoreCase(origin.getHost())
                && (origin.getPort() == -1 || origin.getPort() == 443);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF08130B);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(false);
        settings.setLoadWithOverviewMode(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isTrustedUrl(request.getUrl().toString());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !isTrustedUrl(url);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageReplyProxy = null;
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
            }
        });

        boolean supportsMessageBridge = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER);
        boolean supportsDocumentStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (supportsMessageBridge && supportsDocumentStart) {
            WebViewCompat.addWebMessageListener(webView, HOST_BRIDGE_NAME,
                    Collections.singleton(TRUSTED_ORIGIN), (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                        if (!isMainFrame || !isTrustedOrigin(sourceOrigin)
                                || !isTrustedUrl(view.getUrl())) {
                            Log.w(TAG, "Rejected message from an untrusted WebView frame or URL.");
                            return;
                        }
                        pageReplyProxy = replyProxy;
                        handleHostMessage(message);
                    });
            WebViewCompat.addDocumentStartJavaScript(webView, BRIDGE_BOOTSTRAP,
                    Collections.singleton(TRUSTED_ORIGIN));
        } else {
            // Fail closed: never fall back to addJavascriptInterface, which has no frame-origin check.
            Log.e(TAG, "This Android System WebView lacks secure message-bridge support. Update Android System WebView.");
            Toast.makeText(this, "Update Android System WebView to enable native sign-in and ads.", Toast.LENGTH_LONG).show();
        }

        setContentView(webView);
        webView.loadUrl(TRUSTED_ORIGIN + TRUSTED_PATH + "/");
    }

    private void handleHostMessage(WebMessageCompat message) {
        if (message == null) return;
        String data = message.getData();
        if (data == null || data.length() > 2048) return;
        try {
            JSONObject command = new JSONObject(data);
            String type = command.optString("type", "");
            switch (type) {
                case "ready":
                case "getState":
                    sendBridgeState();
                    break;
                case "loadRewarded":
                    loadRewardedAd();
                    break;
                case "loadInterstitial":
                    loadInterstitialAd();
                    break;
                case "showRewarded":
                    showRewardedAd();
                    break;
                case "showInterstitial":
                    showInterstitialAd();
                    break;
                case "startGoogleSignIn":
                    startGoogleSignIn();
                    break;
                case "clearGoogleSession":
                    clearGoogleSession();
                    break;
                default:
                    Log.w(TAG, "Ignored unknown WebView bridge command.");
                    break;
            }
        } catch (Exception e) {
            Log.w(TAG, "Ignored malformed WebView bridge message.", e);
        }
    }

    private boolean hasGoogleConfig() {
        return !readWebClientId().isEmpty();
    }

    private String readWebClientId() {
        if (cachedWebClientId != null) return cachedWebClientId;
        cachedWebClientId = "";
        try (InputStream in = getAssets().open("google-services.json");
             BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) content.append(line);
            JSONObject root = new JSONObject(content.toString());
            JSONArray clients = root.optJSONArray("client");
            if (clients == null) return cachedWebClientId;
            for (int i = 0; i < clients.length(); i++) {
                JSONObject client = clients.optJSONObject(i);
                JSONObject info = client == null ? null : client.optJSONObject("client_info");
                JSONObject androidInfo = info == null ? null : info.optJSONObject("android_client_info");
                if (androidInfo == null || !getPackageName().equals(androidInfo.optString("package_name"))) continue;
                JSONArray oauth = client.optJSONArray("oauth_client");
                if (oauth == null) continue;
                for (int j = 0; j < oauth.length(); j++) {
                    JSONObject oauthClient = oauth.optJSONObject(j);
                    if (oauthClient != null && oauthClient.optInt("client_type", 0) == 3) {
                        String id = oauthClient.optString("client_id", "");
                        if (!id.isEmpty()) {
                            cachedWebClientId = id;
                            return cachedWebClientId;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Could not read the Firebase Google OAuth client ID.", e);
        }
        return cachedWebClientId;
    }

    private void sendBridgeState() {
        boolean rewardedReady;
        boolean interstitialReady;
        synchronized (adLock) {
            rewardedReady = rewardedAd != null;
            interstitialReady = interstitialAd != null;
        }
        JSONObject state = new JSONObject();
        try {
            state.put("type", "state");
            state.put("rewarded", rewardedReady);
            state.put("interstitial", interstitialReady);
            state.put("googleConfigured", hasGoogleConfig());
        } catch (Exception ignored) {
            return;
        }
        postMessageToPage(state.toString());
    }

    private void postMessageToPage(String message) {
        runOnUiThread(() -> {
            JavaScriptReplyProxy proxy = pageReplyProxy;
            if (proxy == null || webView == null || !isTrustedUrl(webView.getUrl())) return;
            try {
                proxy.postMessage(message);
            } catch (Exception e) {
                Log.w(TAG, "Could not deliver a message to the active game page.", e);
            }
        });
    }

    private void sendRewardEvent(String eventType) {
        JSONObject event = new JSONObject();
        try {
            event.put("type", eventType);
            postMessageToPage(event.toString());
        } catch (Exception ignored) {}
    }

    private void callJs(String script) {
        if (webView == null) return;
        webView.post(() -> {
            if (webView != null && isTrustedUrl(webView.getUrl())) {
                webView.evaluateJavascript(script, null);
            }
        });
    }

    private String jsQuote(String value) {
        return JSONObject.quote(value == null ? "" : value);
    }

    private void startGoogleSignIn() {
        runOnUiThread(() -> {
            String webClientId = readWebClientId();
            if (webClientId.isEmpty()) {
                callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError('Android Google sign-in is not configured yet.');");
                return;
            }
            try {
                GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(webClientId)
                        .requestEmail()
                        .build();
                googleSignInClient = GoogleSignIn.getClient(MainActivity.this, options);
                googleSignInClient.signOut().addOnCompleteListener(task -> {
                    try {
                        if (!isFinishing() && !isDestroyed()) {
                            startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE_SIGN_IN);
                        }
                    } catch (Exception e) {
                        String error = e.getMessage() == null ? "Google sign-in failed. Please retry." : e.getMessage();
                        callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError(" + jsQuote(error) + ");");
                    }
                });
            } catch (Exception e) {
                String error = e.getMessage() == null ? "Google sign-in failed. Please retry." : e.getMessage();
                callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError(" + jsQuote(error) + ");");
            }
        });
    }

    private void clearGoogleSession() {
        runOnUiThread(() -> {
            String webClientId = readWebClientId();
            if (webClientId.isEmpty()) return;
            try {
                GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(webClientId)
                        .requestEmail()
                        .build();
                googleSignInClient = GoogleSignIn.getClient(MainActivity.this, options);
                googleSignInClient.signOut();
            } catch (Exception e) {
                Log.w(TAG, "Could not clear the native Google account selection.", e);
            }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE_SIGN_IN) return;
        try {
            GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
            if (account == null || account.getIdToken() == null || account.getIdToken().isEmpty()) {
                callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError('Google did not return a valid ID token. Please retry.');");
                return;
            }
            callJs("window.FlappyFrogNativeGoogleResult&&window.FlappyFrogNativeGoogleResult(" + jsQuote(account.getIdToken()) + ");");
        } catch (ApiException e) {
            int status = e.getStatusCode();
            String error;
            if (status == 10) {
                error = "Google sign-in configuration error (10). Check the Android package name and SHA-1 certificate.";
            } else if (status == 16) {
                error = "Google sign-in was cancelled or authorization failed (16). Please retry.";
            } else {
                error = "Google sign-in failed (" + status + "). Please retry.";
            }
            callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError(" + jsQuote(error) + ");");
        } catch (Exception e) {
            String error = e.getMessage() == null ? "Google sign-in failed. Please retry." : e.getMessage();
            callJs("window.FlappyFrogNativeGoogleError&&window.FlappyFrogNativeGoogleError(" + jsQuote(error) + ");");
        }
    }

    private void loadRewardedAd() {
        if (!mobileAdsReady || isFinishing() || isDestroyed()) return;
        synchronized (adLock) {
            if (rewardedAd != null || rewardedAdLoading) return;
            rewardedAdLoading = true;
        }
        RewardedAd.load(this, BuildConfig.REWARDED_AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        synchronized (adLock) {
                            rewardedAd = ad;
                            rewardedAdLoading = false;
                        }
                        sendBridgeState();
                    }

                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        synchronized (adLock) {
                            rewardedAd = null;
                            rewardedAdLoading = false;
                        }
                        Log.w(TAG, "Rewarded ad failed to load: " + error.getCode());
                        sendBridgeState();
                    }
                });
    }

    private void showRewardedAd() {
        final RewardedAd ad;
        synchronized (adLock) {
            ad = rewardedAd;
            rewardedAd = null;
        }
        sendBridgeState();
        if (ad == null) {
            sendRewardEvent("rewardUnavailable");
            loadRewardedAd();
            return;
        }

        AtomicBoolean rewardEarned = new AtomicBoolean(false);
        AtomicBoolean terminalSignalSent = new AtomicBoolean(false);
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                if (!rewardEarned.get() && terminalSignalSent.compareAndSet(false, true)) {
                    // Dismissal alone is NOT a reward. Re-open the existing unavailable/retry path.
                    sendRewardEvent("rewardUnavailable");
                }
                loadRewardedAd();
            }

            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                if (terminalSignalSent.compareAndSet(false, true)) sendRewardEvent("rewardUnavailable");
                loadRewardedAd();
            }
        });
        try {
            ad.show(MainActivity.this, rewardItem -> {
                if (terminalSignalSent.compareAndSet(false, true)) {
                    rewardEarned.set(true);
                    sendRewardEvent("rewardEarned");
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Rewarded ad could not be shown.", e);
            if (terminalSignalSent.compareAndSet(false, true)) sendRewardEvent("rewardUnavailable");
            loadRewardedAd();
        }
    }

    private void loadInterstitialAd() {
        if (!mobileAdsReady || isFinishing() || isDestroyed()) return;
        synchronized (adLock) {
            if (interstitialAd != null || interstitialAdLoading) return;
            interstitialAdLoading = true;
        }
        InterstitialAd.load(this, BuildConfig.INTERSTITIAL_AD_UNIT_ID, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        synchronized (adLock) {
                            interstitialAd = ad;
                            interstitialAdLoading = false;
                        }
                        sendBridgeState();
                    }

                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        synchronized (adLock) {
                            interstitialAd = null;
                            interstitialAdLoading = false;
                        }
                        Log.w(TAG, "Interstitial ad failed to load: " + error.getCode());
                        sendBridgeState();
                    }
                });
    }

    private void showInterstitialAd() {
        final InterstitialAd ad;
        synchronized (adLock) {
            ad = interstitialAd;
            interstitialAd = null;
        }
        sendBridgeState();
        if (ad == null) {
            loadInterstitialAd();
            return;
        }
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                loadInterstitialAd();
            }

            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                Log.w(TAG, "Interstitial ad failed to show: " + error.getCode());
                loadInterstitialAd();
            }
        });
        try {
            ad.show(MainActivity.this);
        } catch (Exception e) {
            Log.e(TAG, "Interstitial ad could not be shown.", e);
            loadInterstitialAd();
        }
    }

    private boolean keyboardVisible() {
        Rect visibleFrame = new Rect();
        View root = getWindow().getDecorView();
        root.getWindowVisibleDisplayFrame(visibleFrame);
        int height = root.getRootView().getHeight();
        return height - visibleFrame.bottom > height * 0.18f;
    }

    @Override public void onBackPressed() {
        if (keyboardVisible()) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (webView != null) inputMethodManager.hideSoftInputFromWindow(webView.getWindowToken(), 0);
            if (webView != null) webView.clearFocus();
            return;
        }
        if (webView != null) {
            webView.evaluateJavascript("window.FlappyFrogHandleAndroidBack?window.FlappyFrogHandleAndroidBack():false;", value -> {
                if ("false".equals(value) || "null".equals(value)) finish();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUi();
    }

    @Override protected void onDestroy() {
        pageReplyProxy = null;
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
