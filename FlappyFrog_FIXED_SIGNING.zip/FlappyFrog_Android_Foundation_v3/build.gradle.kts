plugins {
    id("com.android.application") version "8.13.2" apply false
}
