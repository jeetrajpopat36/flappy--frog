# Flappy Frog Android V36 Final Candidate

Package: `com.mauu.flappyfrog`

This candidate keeps the approved gameplay and adds two targeted fixes: robust rewarded-ad readiness/callback handling and a Google Sign-In fallback when Credential Manager returns the Android account re-authentication status 16. The verified Firebase Android `google-services.json` is included.

The app continues to load the GitHub Pages game over HTTPS so Firebase web authentication and the approved gameplay remain unchanged.

Test ad IDs are retained for testing and must be replaced with production AdMob IDs before Play Store release.
