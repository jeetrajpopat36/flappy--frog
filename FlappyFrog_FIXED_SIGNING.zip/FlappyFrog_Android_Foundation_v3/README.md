# Flappy Frog Android — audited candidate

Package: `com.mauu.flappyfrog`

This folder is the Android wrapper for the hosted Flappy Frog web game. The approved hosted game HTML, gameplay physics, pipe settings, score/leaderboard logic and in-game interstitial cadence were intentionally not changed in this correction pass.

## Changes in this candidate

- Replaced the legacy `addJavascriptInterface` objects with an origin-restricted AndroidX WebKit message bridge. Commands are accepted only from the main frame on `https://jeetrajpopat36.github.io/flappy--frog/`.
- Added top-level navigation restrictions to the same trusted HTTPS game path and blocked mixed content / JavaScript-opened windows.
- Fixed rewarded-ad accounting: a revive or other reward is granted only after the SDK's `OnUserEarnedRewardListener` fires. Closing an ad without earning the reward returns to the existing unavailable/retry flow.
- Added guarded, synchronized ad loading/showing to avoid duplicate loads and double-show races.
- Kept the current interstitial ad system and its existing HTML trigger (after every third completed game) unchanged.
- Fixed native Google account sign-out access so the game's existing `AndroidGoogle.clearGoogleSession()` call is actually routed to Android.
- Debug builds use Google's official demo rewarded/interstitial ad units. Release builds retain the existing Flappy Frog ad unit IDs.
- Delayed ad requests until Mobile Ads SDK initialization completes.

## Build requirements

- Android Gradle Plugin 8.13.2 and Gradle 8.13-compatible environment.
- Java 17, Android SDK compile API 36.
- AndroidX WebKit 1.15.0 (minimum SDK 23).
- The permanent signing keystore and passwords must be supplied through the existing `FLAPPY_KEYSTORE_PATH`, `FLAPPY_KEYSTORE_PASSWORD`, `FLAPPY_KEY_ALIAS` and `FLAPPY_KEY_PASSWORD` environment variables. The keystore is deliberately not included in this archive.

## Important external verification still required

This source archive does not contain Firebase Firestore security rules and cannot prove the live Firebase rules or AdMob account configuration. Check the Firestore rules in Firebase Console before release. Also confirm that the production AdMob app ID and release ad-unit IDs belong to the same AdMob account, and ensure your release signing SHA-1 remains registered in Firebase/Google Cloud.

The app's Android `versionCode` remains unchanged because the current Play Console version was not available to inspect. Increment it before uploading a new release, using a value higher than the highest version code already used in Play Console.
