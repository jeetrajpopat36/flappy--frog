# Flappy Frog Android Foundation V2

Package: `com.mauu.flappyfrog`

## What changed from V1
- The app now loads the tested V34 game from the HTTPS GitHub Pages origin instead of `file://`. This is required so the existing Firebase web authentication/Firestore code runs in a real HTTPS environment.
- WebView cookies, DOM storage, JavaScript windows, and Firebase popup support are enabled.
- File/content access is disabled because the app no longer needs to load the game from a local file.
- Safe Browsing is enabled.
- V34 game logic and Firebase configuration were not edited.
- AdMob remains on Google test ad units for development.

## Security plan
- Firebase API keys are public identifiers by design; do not put service-account/private keys in the app.
- Production Firestore Security Rules remain the primary data authorization layer.
- App Check with Play Integrity will be added after the Android app is registered in Firebase/Play Console and its signing certificate SHA-256 is available.
- Real-money competition remains locked until scores can be validated server-side.

## Build
The GitHub Actions workflow builds a debug APK using Gradle on GitHub's cloud runner.
