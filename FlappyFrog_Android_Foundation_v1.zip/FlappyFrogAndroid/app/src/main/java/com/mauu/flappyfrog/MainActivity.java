package com.mauu.flappyfrog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;

    // Google-provided rewarded test unit. Replace only for production.
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUi();

        MobileAds.initialize(this, status -> loadRewardedAd());
        loadInterstitialAd();
        setupWebView();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF08130B);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installJsBridge();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.addJavascriptInterface(new NativeAdsBridge(), "AndroidAds");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/flappy_frog.html");
    }

    private void installJsBridge() {
        String js = "javascript:(function(){window.FlappyFrogNativeAds={" +
                "isAvailable:function(){return !!(window.AndroidAds&&AndroidAds.isRewardedAvailable());}," +
                "showRewardedAd:function(onReward,onUnavailable){" +
                "window.__flappyRewardEarned=onReward;window.__flappyRewardUnavailable=onUnavailable;" +
                "if(window.AndroidAds&&AndroidAds.isRewardedAvailable()){AndroidAds.showRewardedAd();return true;}" +
                "if(onUnavailable)onUnavailable();return false;}," +
                "showInterstitial:function(){if(window.AndroidAds&&AndroidAds.isInterstitialAvailable()){AndroidAds.showInterstitial();return true;}return false;}" +
                "};})()";
        webView.evaluateJavascript(js, null);
    }

    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, TEST_REWARDED_ID, request, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
        });
    }

    private void loadInterstitialAd() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, TEST_INTERSTITIAL_ID, request, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
        });
    }

    private class NativeAdsBridge {
        @JavascriptInterface
        public boolean isRewardedAvailable() {
            return rewardedAd != null;
        }

        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    callJs("window.__flappyRewardUnavailable&&window.__flappyRewardUnavailable();");
                    loadRewardedAd();
                    return;
                }
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.show(MainActivity.this, rewardItem ->
                        callJs("window.__flappyRewardEarned&&window.__flappyRewardEarned();"));
                loadRewardedAd();
            });
        }

        @JavascriptInterface
        public boolean isInterstitialAvailable() {
            return interstitialAd != null;
        }

        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    loadInterstitialAd();
                    return;
                }
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.show(MainActivity.this);
                loadInterstitialAd();
            });
        }
    }

    private void callJs(String script) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override
    public void onBackPressed() {
        // Let the V34 page's own modal/back handling run first.
        if (webView != null) {
            webView.evaluateJavascript("window.FlappyFrogHandleAndroidBack ? window.FlappyFrogHandleAndroidBack() : false;", value -> {
                if ("false".equals(value) || "null".equals(value)) finish();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
    }
}
