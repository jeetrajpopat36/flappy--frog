# Flappy Frog — Android Foundation

Package ID: `com.mauu.flappyfrog`

This project wraps the **tested V34 game build** without changing its gameplay/auth/key/leaderboard HTML.

## Current foundation
- Portrait Android app
- Target/compile API 36 for the current Google Play requirement
- V34 bundled as a local WebView asset
- Fullscreen immersive presentation
- Firebase web configuration remains inside V34
- Native JavaScript bridge for rewarded ads
- Google Mobile Ads SDK 25.4.0
- Google rewarded test ad unit wired for development
- Native interstitial bridge prepared (the current V34 page does not invoke it yet)
- App icon from the approved Flappy Frog artwork
- Application ID: `com.mauu.flappyfrog`

## Build
Open this folder in Android Studio. Use a Gradle 8.13-compatible setup and let Android Studio download dependencies.

Run the `app` configuration on a physical Android device.

### Important
The AdMob App ID and ad unit IDs in this development project are Google test IDs. They MUST be replaced with the real Flappy Frog AdMob IDs before production release. Google explicitly recommends test ads during development.

The V34 HTML is intentionally not modified for this Android foundation. If device testing reveals a WebView-specific Firebase Google-login issue, fix that in the Android layer first rather than changing the V34 game logic.

## Files
- `app/src/main/assets/flappy_frog.html` — frozen V34 game
- `app/src/main/java/com/mauu/flappyfrog/MainActivity.java` — Android shell + ad bridge
- `app/src/main/res/` — icon/theme/resources
